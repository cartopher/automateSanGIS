# store credentials into variables
username = 'ccharleshhi@gmail.com'
password = 'CartopherGIS34'